import { useState } from 'react';

export default function Admin() {
  const [email, setEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [sender, setSender] = useState('');
  const [msg, setMsg] = useState('');

  const addMoney = async () => {
    if (!email || !amount || !sender) {
      setMsg('Fill all fields');
      return;
    }

    const res = await fetch('https://usa-bank-server.up.railway.app/api/admin/add-balance', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        email: email,
        amount: Number(amount),
        senderName: sender
      })
    });

    const data = await res.json();
    if (data.success) {
      setMsg(`$${amount} added from "${sender}" – Email sent!`);
      setEmail(''); setAmount(''); setSender('');
    } else {
      setMsg('User not found or error');
    }
  };

  return (
    <div style={{padding:'40px',background:'#000',color:'white',minHeight:'100vh',fontFamily:'system-ui'}}>
      <h1 style={{textAlign:'center',color:'#ff0000'}}>ADMIN PANEL</h1>
      <p style={{textAlign:'center',opacity:0.8}}>Only you can see this</p>

      <input 
        placeholder="Client Email" 
        value={email} 
        onChange={e=>setEmail(e.target.value)} 
        style={{width:'100%',padding:'18px',margin:'15px 0',borderRadius:'12px',background:'#222',color:'white',border:'none',fontSize:'18px'}}
      />
      <input 
        placeholder="Amount (e.g. 5000000)" 
        value={amount} 
        onChange={e=>setAmount(e.target.value)} 
        style={{width:'100%',padding:'18px',margin:'15px 0',borderRadius:'12px',background:'#222',color:'white',border:'none',fontSize:'18px'}}
      />
      <input 
        placeholder="Sender Name (Elon Musk, IRS, Apple...)" 
        value={sender} 
        onChange={e=>setSender(e.target.value)} 
        style={{width:'100%',padding:'18px',margin:'15px 0',borderRadius:'12px',background:'#222',color:'white',border:'none',fontSize:'18px'}}
      />

      <button 
        onClick={addMoney} 
        style={{width:'100%',padding:'22px',background:'crimson',color:'white',border:'none',borderRadius:'15px',fontSize:'24px',fontWeight:'bold',marginTop:'20px'}}
      >
        ADD MONEY + SEND EMAIL
      </button>

      <p style={{color:'lime',fontSize:'22px',textAlign:'center',marginTop:'30px',fontWeight:'bold'}}>{msg}</p>
      <a href="/" style={{display:'block',textAlign:'center',color:'#00d4ff',marginTop:'40px',fontSize:'18px'}}>Back to Bank</a>
    </div>
  );
}