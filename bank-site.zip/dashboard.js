import { useState, useEffect } from 'react';

export default function Dashboard() {
  const user = typeof window !== 'undefined' && JSON.parse(localStorage.getItem('user') || '{}');
  const [trans, setTrans] = useState([]);

  useEffect(() => {
    if (user.email) {
      fetch('https://usa-bank-server.up.railway.app/api/transactions', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email: user.email})
      })
      .then(r => r.json())
      .then(setTrans);
    }
  }, []);

  if (!user.name) return <div style={{color:'white',padding:'50px',textAlign:'center'}}>Loading...</div>;

  return (
    <div style={{padding:'20px',fontFamily:'system-ui',background:'#000428',color:'white',minHeight:'100vh'}}>
      <div style={{background:'#003087',padding:'20px',textAlign:'center'}}><h1>LIBERTY TRUST BANK</h1></div>

      <h2 style={{margin:'20px 0'}}>Welcome back, {user.name}</h2>
      <div style={{background:'#003087',padding:'30px',borderRadius:'15px',textAlign:'center'}}>
        <p>Available Balance</p>
        <h1 style={{fontSize:'48px'}}>${parseFloat(user.balance||0).toLocaleString('en-US', {minimumFractionDigits: 2})}</h1>
        <p>•••• {user.account?.slice(-4)}</p>
      </div>

      <h3 style={{margin:'30px 0 10px',textAlign:'left'}}>Recent Transactions</h3>
      <div style={{background:'#001f3f',borderRadius:'12px'}}>
        {trans.length === 0 && <p style={{padding:'20px',textAlign:'center',opacity:0.7}}>No transactions yet</p>}
        {trans.map(t => (
          <div key={t.id} style={{padding:'18px',borderBottom:'1px solid #334',display:'flex',justifyContent:'space-between'}}>
            <div>
              <div style={{fontWeight:'bold'}}>{t.sender}</div>
              <div style={{fontSize:'14px',opacity:0.8}}>{new Date(t.date).toLocaleDateString()}</div>
            </div>
            <div style={{color:'#0f0',fontWeight:'bold'}}>+${parseFloat(t.amount).toLocaleString()}</div>
          </div>
        ))}
      </div>

      <button onClick={()=>{localStorage.clear();location.reload()}} 
        style={{marginTop:'50px',width:'100%',padding:'18px',background:'red',color:'white',border:'none',borderRadius:'10px',fontSize:'18px'}}>
        Log Out
      </button>
    </div>
  );
}